#include <iostream>
#include <iomanip>      
#include <ctime>
#include "fixgets.h"
using namespace std;   

int main (void)
{	

char answers [10];

cout << "Enter your name" <<endl;
cin >> answers; 
cout << answers;
return 0;
}